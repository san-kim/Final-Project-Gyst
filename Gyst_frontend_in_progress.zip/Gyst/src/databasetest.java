import java.util.ArrayList;

public class databasetest 
{
	public static void main(String [] args)
	{
		DatabaseAccess da = new DatabaseAccess();
		
		System.out.println("trying to create accounts");
		Account one = da.createAccount("user1", "1");
		Account two = da.createAccount("user2", "2");
		Account three = da.createAccount("user3", "3");
		System.out.println("successfully created accounts");

		System.out.println(da.validate("user1", "1") == true); 	//true
		System.out.println(da.validate("user2", "2") == true);	//true
		System.out.println(da.validate("user3", "3") == true);	//true
		System.out.println(da.validate("user1", "2") == false);	//false
		System.out.println(da.validate("user2", "1") == false);	//false
		System.out.println(da.validate("user12", "12") == false);//false
		
		System.out.println("\n");
		
		System.out.println(da.userExists("user1") == true);
		System.out.println(da.userExists("user12") == false );
		System.out.println(da.ID_Exists(12) == false);
		System.out.println(da.ID_Exists(da.getIDFromUsername("user3")) == true);
		
		System.out.println("\n");

		System.out.println(da.getUsernameFromID(da.getIDFromUsername("user1")));
		System.out.println(da.getIDFromUsername("user2"));
		
		
		System.out.println("\n");
		Event b = new Event(34556, "eventname2", "12:20PM", "12:30PM", "lols notes", "SAL 69", two, true);

		
		Event a = new Event(12345, "eventname1", "12:20PM", "12:30PM", "lols notes", "SAL 69", one, true);
		
		a.addUser(three);
		a.addUser(two);
		
		a.setEventName("changed event name");
		da.changeEvent(a);
		
		ArrayList<EventInfo> ei = da.getEvents(two.getUsername());
		for(int i = 0; i<ei.size(); i++)
		{
			System.out.println(ei.get(i).eventname);
		}
		
		System.out.println(da.isUserInEvent((int)one.getId(), (int)a.getId()));
			
		//da.addEvent("user1", "Ename", "SAL", "12:00PM", "1:50PM", "show up!");
		//da.addEvent("user1", "Ename1", "SAL101", "12:01PM", "1:51PM", "study");
		
		//da.removeToDoEvent("user1", "Ename", "SAL", "12:00PM", "1:50PM", true, "show up!");
		
		//da.changeToDoEvent("user1", "Ename", "SAL", "12:00PM", "1:50PM", true, "show up!","user1", "Ename", "SAL", "11:00AM", "1:50PM", false, "show up!");

		/*
		da.addUserBlock("user1", "lol.com");
		da.addUserBlock("user1", "facebook.com");
		//da.removeUserBlock("user1", "lol.com");
		//da.removeUserBlock("user1", "facebook.com");
		System.out.println(da.getUserBlocks("user1"));

		//da.addBrowseDaily("user1", "hi.com", 2);
		//da.addBrowseDaily("user1", "fb.com", 3);
		da.clearBrowseDaily();
		
		System.out.println(da.getBrowseDaily("user1"));
		
		da.addBrowsePermanent("user1", "ello.com", 5);
		da.addBrowsePermanent("user1", "fasdfb.com", 6);
		
		System.out.println(da.getBrowsePermanent("user1"));
		*/
	}
}
